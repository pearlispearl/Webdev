DROP DATABASE IF EXISTS goodmooddb;
CREATE DATABASE IF NOT EXISTS goodmoodDB;
USE goodmoodDB;

CREATE TABLE admin_info(
	admin_id		char(7),
    firstname		varchar(20),
    lastname		varchar(20),
    phone_no		char(10),
    email			varchar(45),
    photo			varchar(100),
    username 		varchar(30),
    password		varchar(30),
    CONSTRAINT PK_adminid PRIMARY KEY(admin_id)
);

CREATE TABLE product_info(
	prod_id			char(5),
    prod_name		varchar(30),
    prod_price		INT,
    prod_type       varchar(20),
    prod_photo		varchar(100),
    prod_star		INT,
    prod_detail		varchar(200),
    CONSTRAINT PK_prodid PRIMARY KEY (prod_id)
);

CREATE TABLE admin_login(
	username 		varchar(30),
    password		varchar(30),
	timestamp		datetime
);

INSERT INTO admin_info VALUES 
("6587037", "Supisara", "Thonglerts", "0204201100", "supisara.thg@student.mahidol.ac.th", "https://drive.google.com/uc?export=view&id=14lXAoWiF4tSjb0BU7DZIDHeET-iveHrT", "admin037", "sese037"),
("6587077", "Nutthawadee", "Praisri", "0251125001", "nutthawadee.pra@student.mahidol.ac.th", "https://drive.google.com/uc?export=view&id=1doWHmXp7y-sgt7pKb3_DrTicKqDSkw9f", "admin077", "chingching077"),
("6587098","Patraporn", "Sukumphanthanasarn", "0810721999", "patraporn.suu@student.mahidol.ac.th", "https://drive.google.com/uc?export=view&id=1D4Xjr0G-vVQVGJ_ihi0KKFmpRpoD36Yp", "admin098", "patpat098"),
("6587103", "Supisara", "Ngamchaipisit", "0210220001","supisara.nga@student.mahidol.ac.th", "https://drive.google.com/uc?export=view&id=1dhTdM8Q-Osa8Z2DNV5a3Fnyv0RM6Qa-O", "admin103", "mintmint103");

INSERT INTO product_info VALUES
("1","Latte", 50, "Coffee", "https://i.pinimg.com/564x/37/c5/5e/37c55e9e4334ec1aa6bd926137d4a308.jpg",4,"A latte is a popular coffee drink made with espresso and steamed milk, resulting in a creamy texture."),
("2","Strawberry Milk", 100, "Milk", "https://i.pinimg.com/564x/4d/59/e4/4d59e456a374148a02de0727505378fe.jpg",5,"Strawberry milk is a sweet and creamy beverage made by blending fresh or artificial strawberry flavor with milk, creating a pink-hued drink loved for its fruity taste. "),
("3","Chocolate Milk",150, "Milk", "https://i.pinimg.com/564x/82/57/26/8257267b77d839404edecdb7a25f3463.jpg",4,"Our chocolate milk is a luscious blend of creamy, high-quality milk and rich cocoa, creating a deliciously satisfying beverage for any time of day. "),
("4","Cookie",200, "Bakery", "https://i.pinimg.com/564x/87/22/e3/8722e3a3370563e8347afb3b006ebbe5.jpg",3,"Cookies are delicious baked goods typically comprised of flour, sugar, butter, and eggs, offering a delightful treat for any occasion. "),
("5","Chocolate Cake",60, "Bakery", "https://i.pinimg.com/564x/1b/0d/80/1b0d80e6a9033e7a0cfdd2a04908d884.jpg",2,"Chocolate cake is a delectable dessert renowned for its rich, indulgent flavor and moist texture. "),
("6", "Shine Muscat Cake", 70, "Bakery", "https://i.pinimg.com/564x/d7/75/a9/d775a90e73fc827ef3b0dd0308ab05d6.jpg",5, "Shine Muscat cake is a delightful dessert featuring the exquisite flavors of the Shine Muscat grape variety, renowned for its sweet, floral taste. "),
("7", "Blueberry Cheesecake", 80, "Bakery", "https://i.pinimg.com/564x/51/75/65/5175655059fdbeda28140713536cc067.jpg",1, "Blueberry cheesecake is a luscious dessert that combines the creamy richness of cheesecake with the vibrant sweetness of blueberries. "),
("8", "Strawberry Cake", 120, "Bakery", "https://i.pinimg.com/564x/74/95/54/749554ee1f7352b387069f912d1606bc.jpg",5,"Our Strawberry Cake is made with fresh cream, butter cake and fresh strawberry.");

select* from admin_info;
select* from admin_login;
select* from product_info;
select* from product_info;




