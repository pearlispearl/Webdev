//frontend
const express = require('express');
const path = require('path')
const app = express();
const port = 8007

const router = express.Router();
app.use(router)

app.use('/',express.static(path.join(__dirname,'public')));

router.use(express.json());
router.use(express.urlencoded({extended : true}));

/*------------ Customer Zone -----------*/
// homepage
router.get('/',function(req,res){
    res.sendFile(path.join(`${__dirname}/html/homepage.html`))
});
router.get('/homepage',function(req,res){
    res.sendFile(path.join(`${__dirname}/html/homepage.html`))
});

// search
router.get('/search',function(req,res){
    res.sendFile(path.join(`${__dirname}/html/search.html`));
});

// abtuspage
router.get('/abtuspage',function(req,res){
    res.sendFile(path.join(`${__dirname}/html/abtuspage.html`));
});


/*------------ Admin Zone -----------*/
// loginpage
router.get('/loginpage',function(req,res){
    res.sendFile(path.join(`${__dirname}/html/loginpage.html`));
});

// admin
router.get('/admin',function(req,res){
    res.sendFile(path.join(`${__dirname}/html/admin.html`));
});

// new-admin
router.get('/new-admin',function(req,res){
    res.sendFile(path.join(`${__dirname}/html/new-admin.html`));
});

// edit-admin
router.get('/admin-edit/:id',function(req,res){
    res.sendFile(path.join(`${__dirname}/html/edit-admin.html`));
});


/*------------ Product Zone -----------*/
// product-admin
router.get('/product-admin',function(req,res){
    res.sendFile(path.join(`${__dirname}/html/product-admin.html`));
});

// new-product
router.get('/new-product',function(req,res){
    res.sendFile(path.join(`${__dirname}/html/new-product.html`));
});

// product detail
router.get('/productdetail/:productId', (req, res) => {
    res.sendFile(path.join(`${__dirname}/html/productdetail.html`));
    
});

// edit-product
router.get('/product-edit/:id',function(req,res){
    res.sendFile(path.join(`${__dirname}/html/edit-product.html`));
});


app.listen(port, function() {
    console.log('Server listening at port:'+ port)
});