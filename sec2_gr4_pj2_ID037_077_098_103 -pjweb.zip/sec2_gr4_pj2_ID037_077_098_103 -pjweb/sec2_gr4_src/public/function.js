/*------------------- search ----------------- */
//show admin (admin page)
function showadmin(){
    //Fetch Data จาก backend
    fetch('http://localhost:8008/showadmin')

    //Handle Response
    .then(response => response.json())
    .then(data => {
        const admincontainer = document.getElementById('admincontainer');
        data.forEach(member => {
            admincontainer.innerHTML += `
                <tr>
                    <td><img src="${member.photo}" style="width: 35px; height: 35px; border-radius: 3px;"></td>
                    <td>${member.admin_id}</td>
                    <td>${member.firstname}</td>
                    <td>${member.email}</td>
                    <td>
                        <button type="button" class="smallbutton" onclick="edit_admin(${member.admin_id})">Edit</button>
                        <button type="button" class="smallbutton" onclick="delete_admin(${member.admin_id})"><img src="https://i.pinimg.com/564x/75/07/fc/7507fc4b02958513774e7c69e5edf308.jpg" style="width: 10px; height: 10px; border-radius: 3px;"></button>
                    </td>
                </tr>`;
        });
    })

    //Handle Error
    .catch(error => {
        console.error('Error:', error);
    });
}

//search All admin (admin page)
function searchAlladmin(){
    //ดึงค่า query จาก html
    const query = document.getElementById("txtSearch").value;
    
    //สร้าง search detail object
    const searchDetails = {
        query: query
    }
    console.log(searchDetails)

    //Fetch Data จาก backend
    fetch("http://localhost:8008/searchAlladmin", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(searchDetails)
    })

    //Handle Response
    .then(response => response.json())
    .then(data => {
        const searchcontainer = document.getElementById('admincontainer');
        searchcontainer.innerHTML = '';
            data.forEach(admin => {
                searchcontainer.innerHTML += `
                    <tr>
                        <td><img src="${admin.photo}" style="width: 35px; height: 35px; border-radius: 3px;"></td>
                        <td>${admin.admin_id}</td>
                        <td>${admin.firstname}</td>
                        <td>${admin.email}</td>
                        <td>
                            <button type="button" class="smallbutton" onclick="edit_admin(${admin.admin_id})">Edit</button>
                            <button type="button" class="smallbutton" onclick="delete_admin(${admin.admin_id})"><img src="https://i.pinimg.com/564x/75/07/fc/7507fc4b02958513774e7c69e5edf308.jpg" style="width: 10px; height: 10px; border-radius: 3px;"></button>
                        </td>
                    </tr>
                `;

            });
    })

    //Handle Error
    .catch(error => {
        console.error('Error:', error);
    });
}

//search Criteria admin (admin page)
function searchCriteriaAdmin(){
    //ดึงค่า query จาก html
    const queryName = document.getElementById("searchName").value;
    const queryID = document.getElementById("searchID").value;
    const queryPhone = document.getElementById("searchPhone").value;

    //สร้าง search detail object 
    const searchDetails = {
        queryName: queryName,
        queryID: queryID,
        queryPhone: queryPhone
    }
    console.log(searchDetails)

    //Fetch Data จาก backend
    fetch("http://localhost:8008/searchcriteriaAdmin", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(searchDetails)
    })

    //Handle Response
    .then(response => response.json())
    .then(data => {
        const searchcontainer = document.getElementById('admincontainer');
        searchcontainer.innerHTML = '';
            data.forEach(admin => {
                searchcontainer.innerHTML += `
                    <tr>
                        <td><img src="${admin.photo}" style="width: 35px; height: 35px; border-radius: 3px;"></td>
                        <td>${admin.admin_id}</td>
                        <td>${admin.firstname}</td>
                        <td>${admin.email}</td>
                        <td>
                            <button type="button" class="smallbutton" onclick="edit_admin(${admin.admin_id})">Edit</button>
                            <button type="button" class="smallbutton" onclick="delete_admin(${admin.admin_id})"><img src="https://i.pinimg.com/564x/75/07/fc/7507fc4b02958513774e7c69e5edf308.jpg" style="width: 10px; height: 10px; border-radius: 3px;"></button>
                        </td>
                    </tr>
                `;
            });
    })

    //Handle Error
    .catch(error => {
        console.error('Error:', error);
    });
}

//search All product (admin page)
function searchAllProductAdmin(){
    //ดึงค่า query จาก html
    const query = document.getElementById("txtSearch").value;

    //สร้าง search detail object 
    const searchDetails = {
        query: query
    }
    //Fetch Data จาก backend
    fetch("http://localhost:8008/searchallproduct", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(searchDetails)
    })
    //Handle Response
    .then(response => response.json())
    .then(data => {
        const searchcontainer = document.getElementById('productadmincontainer');
        searchcontainer.innerHTML = '';
        data.forEach(product => {
            searchcontainer.innerHTML += `
                <section class="product">
                    <img src="${product.prod_photo}" alt="${product.prod_name}" width="100" height="100">
                    <h3 id="${product.prod_id}">${product.prod_name}</h3>
                    <button type="button" class="smallbutton" onclick="edit_product(${product.prod_id})">Edit</button>
                    <button type="button" class="smallbutton" onclick="delete_product(${product.prod_id})"><img src="https://i.pinimg.com/564x/75/07/fc/7507fc4b02958513774e7c69e5edf308.jpg" style="width: 10px; height: 10px; border-radius: 3px;"></button>
                </section>
            `;
        });
    })
    //Handle Error
    .catch(error => {
        console.error('Error:', error);
    });
}

//search Criteria product (admin page)
function searchCriteriaProductAdmin(){
    //ดึงค่า query จาก html
    const queryCat = document.getElementById("searchCatagory").value;
    const queryRat = document.getElementById("searchRating").value;
    const queryPri = document.getElementById("searchPrice").value;

    //สร้าง search detail object 
    const searchDetails = {
        queryCategory: queryCat,
        queryRating: queryRat,
        queryPrice: queryPri
    }

    //Fetch Data จาก backend
    fetch("http://localhost:8008/searchcriteria", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(searchDetails)
    })

    //Handle Response
    .then(response => response.json())
    .then(data => {
        const searchcontainer = document.getElementById('productadmincontainer');
        console.log(data)
        searchcontainer.innerHTML = '';
        data.forEach(product => {
            searchcontainer.innerHTML += `
                <section class="product">
                    <img src="${product.prod_photo}" alt="${product.prod_name}" width="100" height="100">
                    <h3 id="${product.prod_id}">${product.prod_name}</h3>
                    <button type="button" class="smallbutton" onclick="edit_product(${product.prod_id})">Edit</button>
                    <button type="button" class="smallbutton" onclick="delete_product(${product.prod_id})"><img src="https://i.pinimg.com/564x/75/07/fc/7507fc4b02958513774e7c69e5edf308.jpg" style="width: 10px; height: 10px; border-radius: 3px;"></button>
                </section>
            `;
        });
    })

    //Handle Error
    .catch(error => {
        console.error('Error:', error);
    });
}

//search All product (customer page)
function search(){
    //ดึงค่า query จาก html
    const query = document.getElementById("txtSearch").value;

    //สร้าง search detail object
    const searchDetails = {
        query: query
    }

    //Fetch Data จาก backend
    fetch("http://localhost:8008/searchall", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(searchDetails)
    })
    
    //Handle Response
    .then(response => response.json())
    .then(data => {
        const searchcontainer = document.getElementById('searchcontainer');
        searchcontainer.innerHTML = '';
            data.forEach(product => {
                //สร้าง tag <a href="/productdetail/${product.prod_id}">
                const productLink = document.createElement('a');
                productLink.href = `/productdetail/${product.prod_id}`;

                //สร้าง tag <section class="product">
                const productSection = document.createElement('section');
                productSection.classList.add('product');

                //ใส่ข้อมูลใน tag <section class="product">
                productSection.innerHTML = `
                    <img src="${product.prod_photo}" alt="${product.prod_name}" width="100" height="100">
                    <h3>${product.prod_name}</h3>
                    <h4>price: ${product.prod_price}฿ star: ${product.prod_star}</h4>
                `;

                //searchcontainer.innerhtml += <a><section>...</section></a>
                productLink.appendChild(productSection);
                searchcontainer.appendChild(productLink);

                //~ onclick = "/productdetail/${product.prod_id}"
                productLink.addEventListener('click', (event) => {
                    event.preventDefault();
                    window.location.href = productLink.href;
                });
            });
    })

    //Handle Error
    .catch(error => {
        console.error('Error:', error);
    });
    
}

//search Criteria (customer page)
function searchCriteria(){
    //ดึงค่า query จาก html
    const queryCat = document.getElementById("searchCatagory").value;
    const queryRat = document.getElementById("searchRating").value;
    const queryPri = document.getElementById("searchPrice").value;

    //สร้าง search detail object
    const searchDetails = {
        queryCategory: queryCat,
        queryRating: queryRat,
        queryPrice: queryPri
    }

    //Fetch Data จาก backend
    fetch("http://localhost:8008/searchcriteria", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(searchDetails)
    })

    //Handle Response
    .then(response => response.json())
    .then(data => {
        const searchcontainer = document.getElementById('searchcontainer');
        console.log(data)
        searchcontainer.innerHTML = '';
            data.forEach(product => {
                //สร้าง tag <a href="/productdetail/${product.prod_id}">
                const productLink = document.createElement('a');
                productLink.href = `/productdetail/${product.prod_id}`;

                //สร้าง tag <section class="product">
                const productSection = document.createElement('section');
                productSection.classList.add('product');

                //ใส่ข้อมูลใน tag <section class="product">
                productSection.innerHTML = `
                    <img src="${product.prod_photo}" alt="${product.prod_name}" width="100" height="100">
                    <h3>${product.prod_name}</h3>
                    <h4>price: ${product.prod_price}฿ star: ${product.prod_star}</h4>
                `;

                //searchcontainer.innerhtml += <a><section>...</section></a>
                productLink.appendChild(productSection);
                searchcontainer.appendChild(productLink);

                //~ onclick = "/productdetail/${product.prod_id}"
                productLink.addEventListener('click', (event) => {
                    event.preventDefault();
                    window.location.href = productLink.href;
                });
            });
    })

    //Handle Error
    .catch(error => {
        console.error('Error:', error);
    });
}



/*------------------- admin operation ----------------- */
//login
async function login(){
    console.log("login is now successfully goes inside the function")

    //ดึงค่า query จาก html
    const userName = document.getElementById("txtUsername");
    const pass = document.getElementById("txtPassword")

    //สร้าง login detail object
    const loginDetails = {
        txtUsername: userName.value,
        txtPassword: pass.value
    }
    //Fetch Data จาก backend
    let response = await fetch("http://localhost:8008/form-post", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(loginDetails)
    });
    //Handle Backend Response
    let data = await response.json();

    if(data.login){
        //เรียก function เพื่อบันทึกประวัติการ login
        admin_login();
        return document.location = "/product-admin";
    }
    else{
        return false;
    }
    
}

//login history
async function admin_login() {

    //ดึงค่า query จาก html
    const username = document.getElementById("txtUsername");
    const password = document.getElementById("txtPassword");

    //set variable
    let currentDate = new Date();
    let year = currentDate.getFullYear();
    let month = currentDate.getMonth();
    let day = currentDate.getDate();
    let hours = currentDate.getHours();
    let minutes = currentDate.getMinutes();
    let seconds = currentDate.getSeconds();
    const timestamp = `${year}-${month + 1}-${day} ${hours}:${minutes}:${seconds}`;
 
    //สร้าง admin login detail object
    const adminLoginDetails = {
        username: username.value,
        password: password.value,
        timestamp: timestamp
    }
 
    //Fetch Data จาก backend
    let response = await fetch("http://localhost:8008/admin-login", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(adminLoginDetails)
    });
    let data = await response.json();
}

//insert admin
async function insert_admin() {
    console.log("insert admin is now successfully goes inside the function")

    //ดึงค่า query จาก html
    const adminid = document.getElementById("admin-id");
    const ad_fname = document.getElementById("admin-fname");
    const ad_lname = document.getElementById("admin-lname");
    const ad_phone = document.getElementById("admin-phone");
    const ad_email = document.getElementById("admin-email");
    const ad_photo = document.getElementById("admin-photo");
 
    const username = document.getElementById("admin-username");
    const password =document.getElementById("admin-pwd");
 
    //สร้าง admin detail object
    const adminDetail = {
        adminDetail:
        {
            admin_id: adminid.value,
            firstname: ad_fname.value,
            lastname: ad_lname.value,
            phone_no: ad_phone.value,
            email: ad_email.value,
            photo: ad_photo.value,
            username: username.value,
            password: password.value
        }
    }
 
    //Fetch Data จาก backend
    let response = await fetch("http://localhost:8008/admin", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(adminDetail)
    });
 
    //Handle Response
    let data = await response.json();
 
    if (!data.error) return document.location = "/admin";
    return false;
}

//change path to edit admin
function edit_admin(adminId){
    console.log("change path to edit admin")
    window.location.href = `/admin-edit/${adminId}`;
}

//show admin detail (admin page)
function fetchadmindetail() {
    console.log("fetchadmindetail is now successfully goes inside the function")
    //ดึงค่า ID จาก URL
    const urlParams = window.location.pathname.split('/');
    const adminID = urlParams[urlParams.length - 1];
 
    //Fetch Data จาก backend
    fetch(`http://localhost:8008/admin-edit/${adminID}`)

    //Handle Response
    .then(response => response.json())
    .then(admin => {
        console.log(admin.firstname)
        const adminbox = document.getElementById('boxforadmin');
        if (admin) {
            adminbox.innerHTML = `
                <div class="editform">
                <h2 class="lefthead">Edit user</h2>
                <label>Admin ID</label>
                <input type="text" name="admin-id" value="${admin.admin_id}" id="admin-id">
                <br>          
                <label>Firstname</label>
                <input type="text" name="admin-fname" value="${admin.firstname}" id="admin-fname">
                <br>
                <label>Lastname</label>
                <input type="text" name="admin-name" value="${admin.lastname}" id="admin-lname">
                <br>
                <label>Phone Number</label>
                <input type="text" name="admin-name" value="${admin.phone_no}" id="admin-phone">
                <br>
                <label>Email</label>
                <input type="text" name="admin-email" value="${admin.email}" id="admin-email">
                <br>
                <label>Photo</label>
                <input type="text" name="admin-photo" value="${admin.photo}" id="admin-photo">
                <br>
                <label>Username</label>
                <input type="text" name="admin-username" value="${admin.username}"id="admin-username">
                <br>
                <label>Password</label>
                <input type="password" name="admin-password" value="${admin.password}"id="admin-password">
                <br>
                <button type="submit" class="editbutton" onclick="update_admin()">Save Changes</button>
                <a href="/admin"><button type="button" class="editbutton">Close</button></a>
            </div>`
        } else {
            adminbox.innerHTML = `<p>admin not found</p>`;
        }
    })

    //Handle Error
    .catch(error => console.log('Error fetching admin', error));
}

//update admin
async function update_admin(){
    console.log("update admin is now successfully goes inside the function")

    //ดึงค่า query จาก html
    const admin_id = document.getElementById("admin-id");
    const admin_fname = document.getElementById("admin-fname");
    const admin_lname = document.getElementById("admin-lname");
    const admin_phone = document.getElementById("admin-phone");
    const admin_email = document.getElementById("admin-email");
    const admin_photo = document.getElementById("admin-photo");
    const admin_username = document.getElementById("admin-username");
    const admin_password = document.getElementById("admin-password");
   
    //สร้าง admin detail object
    const adminDetails = {
        adminDetail: {
            admin_id: admin_id.value,
            firstname: admin_fname.value,
            lastname: admin_lname.value,
            phone_no: admin_phone.value,
            email: admin_email.value,
            photo: admin_photo.value,
            username: admin_username.value,
            password: admin_password.value
        }
    }

    //Fetch Data จาก backend
    let response = await fetch("http://localhost:8008/admin-edit", {
        method: "PUT",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(adminDetails)
    });

    //Handle Response
    let data = await response.json();

    if(!data.error) return document.location = "/admin";
    return false;
}

//delete admin
async function delete_admin(a){
    console.log("delete admin is now successfully goes inside the function")
    
    //ดึงค่า parameter
    const admin_id = a
    console.log(admin_id)

    //สร้าง admin ID object
    const adminID = {
        admin_id: a
    }
 
    //Fetch Data จาก backend
    let response = await fetch("http://localhost:8008/admin-del", {
        method: "DELETE",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(adminID)
    });

    //Handle Response
    let data = await response.json();
    console.log(data)
   
    if(!data.error) return document.location = "/admin";
    return false;
}

/*------------------- product operation ----------------- */
//insert product
async function insert_product() {
    console.log("insert product frontend is now successfully goes inside the function")
 
    //ดึงค่า query จาก html
    const productid = document.getElementById("product-id");
    const product_name = document.getElementById("product-name");
    const product_price = document.getElementById("product-price");
    const product_type = document.getElementById("product-type");
    const product_photo = document.getElementById("product-photo");
    const product_star = document.getElementById("product-star");
    const product_detail = document.getElementById("product-detail");
 
    //สร้าง product detail object
    const productDetail = {
        productDetail:
        {
            prod_id: productid.value,
            prod_name: product_name.value,
            prod_price: product_price.value,
            prod_type: product_type.value,
            prod_photo: product_photo.value,
            prod_star: product_star.value,
            prod_detail: product_detail.value,
        }
    }
 
    //Fetch Data จาก backend
    let response = await fetch("http://localhost:8008/product-insert", {
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(productDetail)
    });
 
    //Handle Response
    let data = await response.json();
    console.log(data)
 
    if (!data.error) return document.location = "/product-admin";
    return false;  
}

//showproduct
function showproduct() {
    console.log("show product is now successfully goes inside the function")

    //Fetch Data จาก backend
    fetch('http://localhost:8008/product')

    //Handle Response
    .then(response => response.json())
    .then(data => {
        const productadmincontainer = document.getElementById('productadmincontainer');

        data.forEach(product => {
            productadmincontainer.innerHTML += `
                <section class="product">
                    <img src="${product.prod_photo}" alt="${product.prod_name}" width="100" height="100">
                    <h3 id="${product.prod_id}">${product.prod_name}</h3>
                    <button type="button" class="smallbutton" onclick="edit_product(${product.prod_id})">Edit</button>
                    <button type="button" class="smallbutton" onclick="delete_product(${product.prod_id})"><img src="https://i.pinimg.com/564x/75/07/fc/7507fc4b02958513774e7c69e5edf308.jpg" style="width: 10px; height: 10px; border-radius: 3px;"></button>
                </section>
            `;
        });
    })

    //Handle Error
    .catch(error => console.error('Error fetching', error));
}

//show product detail (customer page)
function showProductDetail(){
    console.log("show product detail is now successfully goes inside the function")

    //ดึงค่า ID จาก URL
    const urlParams = window.location.pathname.split('/');
    const productID = urlParams[urlParams.length - 1];
    console.log(productID)
   
    //Fetch Data จาก backend
    fetch(`http://localhost:8008/product-edit/${productID}`)

    //Handle Response
    .then(response => response.json())
    .then(product =>{
        const productbox = document.getElementById('productcontainer');
        if(product){
            productbox.innerHTML = `
                <section class="productpic">
                    <img src="${product.prod_photo}" alt="${product.prod_name}" width="300" height="300">
                    <h2>${product.prod_name}</h2>
                    <h4>price: ${product.prod_price} ฿</h4>
                    <h4>type: ${product.prod_type}</h4>
                    <h4>star: ${product.prod_star}</h4>
                    <h4>details: ${product.prod_detail}</h4>
                </section>`;
        }else{
            productbox.innerHTML=`<p>Product not found</p>`;
        }
    })

    //Handle Error
    .catch(error => console.log('Error fetching product', error));
}

//change path to edit product
function edit_product(productId){
    console.log("change path to edit product")
    window.location.href =`/product-edit/${productId}`;
}

//show product detail
function fetchinputproductdetail(){
    console.log("fetchinputproductdetail is now successfully goes inside the function")

    //ดึงค่า ID จาก URL
    const urlParams = window.location.pathname.split('/');
    const productID = urlParams[urlParams.length - 1];
    console.log(productID)
    
    //Fetch Data จาก backend
    fetch(`http://localhost:8008/product-edit/${productID}`)

    //Handle Response
    .then(response => response.json())
    .then(product =>{
        const productbox = document.getElementById('boxforproduct');
        if(product){
            productbox.innerHTML = `
            <div class="editform">
            <h2 class="lefthead">Edit Details</h2>
            <img src="${product.prod_photo}" alt="${product.prod_name}" width="300" height="300"><br>
            <label>Product ID</label>
            <input type="text" id="prod-id" value ="${product.prod_id}">
            <br>  
            <label>Name</label>
            <input type="text" id="prod-name" value ="${product.prod_name}">
            <br>
            <label>Price</label>
            <input type="text" id="prod-price" value ="${product.prod_price}">
            <br>
            <label>Type</label>
            <input type="text" id="prod-type" value="${product.prod_type}">
            <br>
            <label>Photo</label>
            <input type="text" id="prod-photo" value="${product.prod_photo}">
            <br>
            <label>Star</label>
            <input type="text" id="prod-star" value="${product.prod_star}">
            <br>
            <label>Detail</label>
            <input type="text" id="prod-detail" value="${product.prod_detail}">
            <br>
            <button type="submit" class="editbutton" onclick="update_product()">Save Changes</button>
            <a href="/product-admin"><button type="button" class="editbutton">Close</button></a>
        </div>`;
        }else{
            productbox.innerHTML=`<p>Product not found</p>`;
        }
    })
    //Handle Error
    .catch(error => console.log('Error fetching product', error));
}

//update product
async function update_product(){
    console.log("update product is now successfully goes inside the function")

    //ดึงค่า query จาก html
    const prod_id = document.getElementById("prod-id");
    const prod_name = document.getElementById("prod-name");
    const prod_price = document.getElementById("prod-price");
    const prod_type = document.getElementById("prod-type");
    const prod_photo = document.getElementById("prod-photo");
    const prod_star = document.getElementById("prod-star");
    const prod_detail = document.getElementById("prod-detail");
   
    //สร้าง productDetails object
    const productDetails = {
        productDetail: {
            prod_id: prod_id.value,
            prod_name: prod_name.value,
            prod_price: prod_price.value,
            prod_type: prod_type.value,
            prod_photo: prod_photo.value,
            prod_star: prod_star.value,
            prod_detail: prod_detail.value
        }
    }
    console.log(productDetails);
 
    //Fetch Data จาก backend
    let response = await fetch(`http://localhost:8008/product-edit`, {
        method: "PUT",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(productDetails)
    });

    //Handle Response
    let data = await response.json();
    console.log(data)
   
    if(!data.error) return document.location = "/product-admin";
    return false;
}

//delete product
async function delete_product(a){
    console.log("delete product is now successfully goes inside the function")

    //ดึงค่า query จาก parameter
    const prod_id = a;
 
    //สร้าง ProdID object
    const ProdID = {
        prod_id: prod_id
    }
    console.log(ProdID)
 
    //Fetch Data จาก backend
    let response = await fetch("http://localhost:8008/product-del", {
        method: "DELETE",
        headers: {
            "Content-Type": "application/json"
        },
        body: JSON.stringify(ProdID)
    });

    //Handle Response
    let data = await response.json();
    console.log(data)
   
    if(!data.error) return document.location = "/product-admin";
    return false;
}




