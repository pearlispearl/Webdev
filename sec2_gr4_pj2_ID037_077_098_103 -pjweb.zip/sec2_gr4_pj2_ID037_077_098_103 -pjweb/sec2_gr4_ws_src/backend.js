const express = require('express');
const path = require('path')
const app = express();
const cors = require('cors');

const router = express.Router();
app.use(router)
router.use(cors());

// handling POST req
router.use(express.json())
router.use(express.urlencoded({extended: true}))

// Import and use Env. Variable
const dotenv = require('dotenv');
dotenv.config();

// Connection to mysql
const mysql = require('mysql2');
var connection = mysql.createConnection({
    host: process.env.MYSQL_HOST,
    user: process.env.MYSQL_USERNAME,
    password: process.env.MYSQL_PASSWORD,
    database: process.env.MYSQL_DATABASE
});

// Connection to DB
connection.connect(function(err){
    if(err) throw err;
    console.log(`Connected DB: ${process.env.MYSQL_DATABASE}`);
});

/*------------------- search ----------------- */
//search All product (customer page)
/* Testing 1 Search All product (customer page)
method: post
URL: https://localhost:8008/searchall
body: raw json
{
    "query": "cake"
}
*/
/* Testing 2 Search All product (customer page)
method: post
URL: https://localhost:8008/searchall
body: raw json
{
    "query": "bak"
}
*/

router.post('/searchall', (req, res) => {
    //ดึงค่า query จาก body
    const query = req.body.query;
    console.log(query)

    const sql = `
        SELECT * FROM product_info
        WHERE prod_name LIKE ? OR prod_price LIKE ? OR prod_star LIKE ? OR prod_type LIKE ?
    `;
    const params = [`%${query}%`, `%${query}%`, `%${query}%`, `%${query}%`];

    //ค้นหาจาก database
    connection.query(sql, params, (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: true, message: 'Internal Server Error' });
        }
        res.json(results);
    });
});

//search All product (admin page)
/* Testing 1 Search All product (admin page)
method: post
URL: https://localhost:8008/searchallproduct
body: raw json
{
    "query": "bak"
}
*/
/* Testing 2 Search All product (admin page)
method: post
URL: https://localhost:8008/searchallproduct
body: raw json
{
    "query": "50"
}
*/
router.post('/searchallproduct', (req, res) => {
    //ดึงค่า query จาก body
    const query = req.body.query;

    const sql = `
        SELECT * FROM product_info
        WHERE prod_name LIKE ? OR prod_price LIKE ? OR prod_star LIKE ? OR prod_type LIKE ? OR prod_id LIKE ?
    `;
    const params = [`%${query}%`, `%${query}%`, `%${query}%`, `%${query}%`, `%${query}%`];

    //ค้นหาจาก database
    connection.query(sql, params, (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: true, message: 'Internal Server Error' });
        }
        res.json(results);
    });
});

//search Criteria product (customer page / admin page)
/* Testing 1 search Criteria product (customer page / admin page)
method: post
URL: https://localhost:8008/searchcriteria
body: raw json
{
    "queryCategory": "ba",
    "queryRating": "2",
    "queryPrice": "60"
}
*/
/* Testing 2 search Criteria product (customer page / admin page)
method: post
URL: https://localhost:8008/searchcriteria
body: raw json
{
    "queryCategory": "of",
    "queryRating": "4",
    "queryPrice": ""
}
*/
router.post('/searchcriteria', (req, res) => {
    //ดึงค่า query จาก body
    const queryCat = req.body.queryCategory;
    const queryRat = req.body.queryRating;
    const queryPri = req.body.queryPrice;

    //ตรวจสอบเงื่อนไข
    if(queryCat.length>0){
        if(queryRat.length>0){
            if(queryPri.length>0){
                //input Category, Rating, Price
                connection.query(`
                    SELECT * FROM product_info
                    WHERE prod_type LIKE "%${queryCat}%" and
                    prod_star LIKE "%${queryRat}%" and
                    prod_price LIKE "%${queryPri}%"`,
                    function (error, results) {
                        if (error) throw error;
                        res.json(results);
                    });
            }
            if(queryPri.length==0){
                //input Category, Rating
                console.log("cat rat")
                connection.query(`
                    SELECT * FROM product_info
                    WHERE prod_type LIKE "%${queryCat}%" and
                    prod_star LIKE "%${queryRat}%"`,
                    function (error, results) {
                        if (error) throw error;
                        res.json(results);
                    });
            }
        }
        if(queryRat.length==0){
            if(queryPri.length>0){
                //input Category, Price
                connection.query(`
                    SELECT * FROM product_info
                    WHERE prod_type LIKE "%${queryCat}%" and
                    prod_price LIKE "%${queryPri}%"`,
                    function (error, results) {
                        if (error) throw error;
                        res.json(results);
                    });
            }
            if(queryPri.length==0){
                //input Category
                connection.query(`
                    SELECT * FROM product_info
                    WHERE prod_type LIKE "%${queryCat}%"`,
                    function (error, results) {
                        if (error) throw error;
                        res.json(results);
                    });
            }
        }
    }
    
    else if(queryCat.length==0){
        if(queryRat.length>0){
            if(queryPri.length>0){
                //input Rating, Price
                connection.query(`
                    SELECT * FROM product_info
                    WHERE prod_star LIKE "%${queryRat}%" and
                    prod_price LIKE "%${queryPri}%"`,
                    function (error, results) {
                        if (error) throw error;
                        res.json(results);
                    });
            }
            if(queryPri.length==0){
                //input Rating
                connection.query(`
                    SELECT * FROM product_info
                    WHERE prod_star LIKE "%${queryRat}%"`,
                    function (error, results) {
                        if (error) throw error;
                        res.json(results);
                    });
            }
        }
        if(queryRat.length==0){
            if(queryPri.length>0){
                //input Price
                connection.query(`
                    SELECT * FROM product_info
                    WHERE prod_type LIKE "%${queryCat}%" and
                    prod_price LIKE "%${queryPri}%"`,
                    function (error, results) {
                        if (error) throw error;
                        res.json(results);
                    });
            }
            if(queryPri.length==0){
                //no input
                console.log("nothing")
                connection.query("SELECT * FROM product_info", function (error, results) {
                    if (error) throw error;
                    res.json(results);
                    console.log(results);
                });
            }
        }
    }
});

//search All admin (admin page)
/* Testing 1 search All admin (admin page)
method: post
URL: https://localhost:8008/searchAlladmin
body: raw json
{
    "query": "supi"
}
*/
/* Testing 2 search All admin (admin page)
method: post
URL: https://localhost:8008/searchAlladmin
body: raw json
{
    "query": "nut"
}
*/
router.post('/searchAlladmin', (req, res) => {
    //ดึงค่า query จาก body
    const query = req.body.query;
    const sql = `
        SELECT * FROM admin_info
        WHERE firstname LIKE ? OR lastname LIKE ? OR admin_id LIKE ? OR username LIKE ?
    `;
    const params = [`%${query}%`, `%${query}%`, `%${query}%`, `%${query}%`];

    //ค้นหาจาก database
    connection.query(sql, params, (err, results) => {
        if (err) {
            console.error(err);
            return res.status(500).json({ error: true, message: 'Internal Server Error' });
        }
        res.json(results);
    });
});

//search Criteria admin (admin page)
/* Testing 1 search Criteria admin (admin page)
method: post
URL: https://localhost:8008/searchcriteriaAdmin
body: raw json
{
    "queryName": "supi",
    "queryID": "6587",
    "queryPhone": "020"
}
*/
/* Testing 2 search Criteria admin (admin page)
method: post
URL: https://localhost:8008/searchcriteriaAdmin
body: raw json
{
    "queryName": "",
    "queryID": "7",
    "queryPhone": "02"
}
*/
router.post('/searchcriteriaAdmin', (req, res) => {
    //ดึงค่า query จาก body
    const queryName = req.body.queryName;
    const queryID = req.body.queryID;
    const queryPhone = req.body.queryPhone;

    //ตรวจสอบเงื่อนไข
    if(queryName.length>0){
        if(queryID.length>0){
            if(queryPhone.length>0){
                //input Name, ID, Phone No.
                connection.query(`
                    SELECT * FROM admin_info
                    WHERE (firstname LIKE "%${queryName}%" or lastname LIKE "%${queryName}%") and 
                    admin_id LIKE "%${queryID}%" and 
                    phone_no LIKE "%${queryPhone}%"`, 
                    function (error, results) {
                        if (error) throw error;
                        res.json(results);
                    });
            }
            if(queryPhone.length==0){
                //input Name, ID
                connection.query(`
                    SELECT * FROM admin_info
                    WHERE (firstname LIKE "%${queryName}%" or lastname LIKE "%${queryName}%") and
                    admin_id LIKE "%${queryID}%"`,
                    function (error, results) {
                        if (error) throw error;
                        res.json(results);
                    });
            }
        }
        if(queryID.length==0){
            if(queryPhone.length>0){
                //input Name, Phone No.
                connection.query(`
                    SELECT * FROM admin_info
                    WHERE firstname LIKE (firstname LIKE "%${queryName}%" or lastname LIKE "%${queryName}%") and
                    phone_no LIKE "%${queryPhone}%"`,
                    function (error, results) {
                        if (error) throw error;
                        res.json(results);
                    });
            }
            if(queryPhone.length==0){
                //input Name
                connection.query(`
                    SELECT * FROM admin_info
                    WHERE firstname LIKE "%${queryName}%" or lastname LIKE "%${queryName}%"`,
                    function (error, results) {
                        if (error) throw error;
                        res.json(results);
                    });
            }
        }
    }
    
    if(queryName.length==0){
        if(queryID.length>0){
            if(queryPhone.length>0){
                //input ID, Phone No.
                connection.query(`
                    SELECT * FROM admin_info
                    WHERE admin_id LIKE "%${queryID}%" and
                    phone_no LIKE "%${queryPhone}%"`,
                    function (error, results) {
                        if (error) throw error;
                        res.json(results);
                    });
            }
            if(queryPhone.length==0){
                //input ID
                connection.query(`
                    SELECT * FROM admin_info
                    WHERE admin_id LIKE "%${queryID}%"`,
                    function (error, results) {
                        if (error) throw error;
                        res.json(results);
                    });
            }
        }
        if(queryID.length==0){
            if(queryPhone.length>0){
                //input Phone No.
                connection.query(`
                    SELECT * FROM admin_info
                    WHERE phone_no LIKE "%${queryPhone}%"`,
                    function (error, results) {
                        if (error) throw error;
                        res.json(results);
                    });
            }
            if(queryPhone.length==0){
                //no input
                connection.query("SELECT * FROM admin_info",
                function (error, results) {
                    if (error) throw error;
                    res.json(results);
                });
            }
        }
    }
});


/*------------------- admin operation ----------------- */
//Authentication
/* Testing 1 Authentication
method: post
URL: https://localhost:8008/form-post
body: raw json
{
    "txtUsername": "admin037",
    "txtPassword": "sese037"
}
*/
/* Testing 2 Authentication
method: post
URL: https://localhost:8008/form-post
body: raw json
{
    "txtUsername": "admin098",
    "txtPassword": "patpat098"
}
*/
router.post('/form-post',function(req,res){
    //ดึงค่า query จาก body
    const username = req.body.txtUsername;
    const password = req.body.txtPassword;
    
    //ค้นหาจาก database
    connection.query('Select * FROM admin_info where username =? && password = ?', [username,password], function(err, results){
        if (results.length == 0 ){
            console.log("cannot login");
            return res.send({login: false, mesaage: "Authenication failed"})
        }else{
            console.log(username+","+password);
            console.log("login success");
            return res.send({login: true, meassge: "authenication sucessed"})
        }
    });
});

//login history
/* Testing 1 login history
method: post
URL: https://localhost:8008/admin-login
body: raw json
{
    "username": "admin037",
    "password": "sese037",
    "timestamp": "2023-11-20 20:07:45"
}
*/
/* Testing 2 login history
method: post
URL: https://localhost:8008/admin-login
body: raw json
{
    "username": "admin098",
    "password": "patpat098",
    "timestamp": "2023-15-20 20:07:45"
}
*/
router.post('/admin-login', function (req, res) {
    //ดึงค่า query จาก body
    const adminLoginDetails = req.body;

    //insert into database
    connection.query("INSERT into admin_login SET ?", adminLoginDetails, function (error, results) {
        if (error) throw error;      
        return res.send({ error: false, data: results.affectedRows, message: 'New admin login has been created successfully.' });
    });
})

//show login history
/* Testing show login history
method: get
URL: https://localhost:8008/admin-login
*/
router.get('/admin-login', function (req, res) {
    //ค้นหาจาก database
    connection.query('SELECT * FROM admin_login', function (err, results) {
        if (err) throw err;
        return res.send(results);
    });
});

// Show admin
/* Testing Show admin
method: get
URL: https://localhost:8008/showadmin
*/
router.get('/showadmin',function(req,res){
    //ค้นหาจาก database
    connection.query('Select * FROM admin_info',function(error, results){
        if (error) throw error;
        res.json(results);
    });
});

//show admin detail
/* Testing show admin detail
method: get
URL: https://localhost:8008/admin-edit/6587098
*/
router.get('/admin-edit/:id', function(req,res){
    //ดึงค่า query จาก parameter
    const adminId = req.params.id;

    //ค้นหาจาก database
    connection.query("Select * From admin_info WHERE admin_id = ?",adminId, function(error,results){
        if (error) throw error;
        res.json(results[0]);
    })
})

//insert admin
/* Testing 1 insert admin
method: post
URL: https://localhost:8008/admin
body: raw json
{
    "adminDetail":{
        "admin_id": "6587106",
        "firstname": "sitthida",
        "lastname": "srithana",
        "phone_no": "0858885555",
        "email": "sitthida.sri@student.mahidol.ac.th",
        "photo": "https://i.pinimg.com/564x/07/f7/dd/07f7dd40afa7fd4b55b7d4b29045457a.jpg",
        "username": "admin106",
        "password": "annann106"
    }
}
*/
/* Testing 2 insert admin
method: post
URL: https://localhost:8008/admin
body: raw json
{
    "adminDetail":{
        "admin_id": "6587107",
        "firstname": "anntonea",
        "lastname": "posue",
        "phone_no": "0865781145",
        "email": "anntonea@student.mahidol.ac.th",
        "photo": "https://i.pinimg.com/564x/b8/32/30/b8323060f5852c9233fac79de75ff9f9.jpg",
        "username": "admin107",
        "password": "toto107"
    }
}
*/
router.post('/admin', function (req, res) {
    //ดึงค่า query จาก body
    const admin = req.body.adminDetail;
 
    //insert into database
    connection.query("INSERT into admin_info SET ?", admin, function (error, results) {
        if (error) throw error;
        return res.send({ error: false, data: results.affectedRows, message: 'New admin has been created successfully.' });
    });
});

//update admin
/* Testing 1 update admin
method: put
URL: https://localhost:8008/admin-edit
body: raw json
{
    "adminDetail":{
        "admin_id": "6587106",
        "firstname": "sitthida",
        "lastname": "srithanakriti",
        "phone_no": "0658882541",
        "email": "sitthida.sri@student.mahidol.edu",
        "photo": "https://i.pinimg.com/564x/07/f7/dd/07f7dd40afa7fd4b55b7d4b29045457a.jpg",
        "username": "admin106",
        "password": "annann106"
    }
}
*/
/* Testing 2 update admin
method: put
URL: https://localhost:8008/admin-edit
body: raw json
{
    "adminDetail":{
        "admin_id": "6587106",
        "firstname": "anntoneaaaaaaaaaaaaaa",
        "lastname": "sritrei",
        "phone_no": "0689563214",
        "email": "posuuee.sri@student.mahidol.edu",
        "photo": "https://i.pinimg.com/564x/07/f7/dd/07f7dd40afa7fd4b55b7d4b29045457a.jpg",
        "username": "admin107",
        "password": "toto107"
    }
}
*/
router.put('/admin-edit', function (req, res) {
    //ดึงค่า query จาก body
    let admin_id = req.body.adminDetail.admin_id;
    let admin = req.body.adminDetail;

    //update database
    connection.query("UPDATE admin_info SET ? WHERE admin_id = ?", [admin, admin_id], function (error, results) {
        if (error) throw error;
        return res.send({ error: false, data: results.affectedRows, message: "Admin has been updated successfully" });
    });
});

//delete admin
/* Testing 1 delete admin
method: delete
URL: https://localhost:8008/admin-del
body: raw json
{
    "admin_id": "6587106"
}
*/
/* Testing 2 delete admin
method: delete
URL: https://localhost:8008/admin-del
body: raw json
{
    "admin_id": "6587107"
}
*/
router.delete('/admin-del', function (req, res) {
    //ดึงค่า query จาก body
    let admin_id = req.body.admin_id;

    //ตรวจสอบว่ามีอยู่จริงมั้ย
    if (!admin_id) {
        return res.status(400).send({ error: true, message: 'Please provide admin_id' });
    }

    //delete from database
    connection.query("DELETE FROM admin_info where admin_id = ?", [admin_id], function (error, results) {
        if (error) throw error;
        return res.send({ error: false, data: results.affectedRows, message: 'Admin has been deleted successfully' });
    });
});


/*------------------- product operation ----------------- */
// Show product
/* Testing Show product
method: get
URL: https://localhost:8008/product
*/
router.get('/product',function(req,res){
    //ค้นหาจาก database
    connection.query('Select * FROM product_info',function(error, results){
        if (error) throw error;
        res.json(results);
    });
});

//show product detail
/* Testing show product detail
method: get
URL: https://localhost:8008/product-edit/1
*/
router.get('/product-edit/:id', function (req, res) {
    //ดึงค่า query จาก parameter
    const productId = req.params.id;

    //ค้นหาจาก database
    connection.query("SELECT * FROM product_info WHERE prod_id = ?", productId, function (error, results) {
        if (error) throw error;
        if (results.length > 0) {
            res.json(results[0]);
        } else {
            res.status(404).json({ message: 'Product not found' });
        }
    });
});

//insert product
/* Testing 1 insert product
method: post
URL: https://localhost:8008/product-insert
body: raw json
{
    "productDetail":{
        "prod_id": "9",
        "prod_name": "matcha cake",
        "prod_price": "80",
        "prod_type": "bakery",
        "prod_photo": "https://i.pinimg.com/564x/53/8b/9e/538b9e2ad37aa80240463afce415e8ec.jpg",
        "prod_star": "4",
        "prod_detail": "Matcha Cake a delightful fusion of rich matcha"
    }
}
*/
/* Testing 2 insert product
method: post
URL: https://localhost:8008/product-insert
body: raw json
{
    "productDetail":{
        "prod_id": "10",
        "prod_name": "cheesecake",
        "prod_price": "80",
        "prod_type": "bakery",
        "prod_photo": "https://i.pinimg.com/564x/53/ff/e2/53ffe2ce6d416ba5dd9492580c4e8251.jpg",
        "prod_star": "2",
        "prod_detail": "cheesseee cake"
    }
}
*/
router.post('/product-insert', function (req, res) {
    //ดึงค่า query จาก body
    const product = req.body.productDetail;

    //ตรวจสอบว่าได้ให้ข้อมูลมามั้ย
    if (!product) {
        return res.status(400).send({ error: true, message: 'Please provide product information' });
    }

    //insert to database
    connection.query("INSERT into product_info SET ?", product, function (error, results) {
        if (error) throw error;
        return res.send({ error: false, data: results.affectedRows, message: 'New product has been created successfully.' });
    });
});

// update product
/* Testing 1 update product
method: put
URL: https://localhost:8008/product-edit
body: raw json
{
    "productDetail":{
        "prod_id": "9",
        "prod_name": "matcha cake",
        "prod_price": "120",
        "prod_type": "bakery",
        "prod_photo": "https://i.pinimg.com/564x/53/8b/9e/538b9e2ad37aa80240463afce415e8ec.jpg",
        "prod_star": "2",
        "prod_detail": "Matcha Cake with matcha cha cha"
    }
}
*/
/* Testing 2 update product
method: put
URL: https://localhost:8008/product-edit
body: raw json
{
    "productDetail":{
        "prod_id": "10",
        "prod_name": "cheese cakeeeeee",
        "prod_price": "120",
        "prod_type": "milk",
        "prod_photo": "https://i.pinimg.com/564x/53/ff/e2/53ffe2ce6d416ba5dd9492580c4e8251.jpg",
        "prod_star": "5",
        "prod_detail": "cheeese cak for jerry"
    }
}
*/
router.put('/product-edit', function (req, res) {
    //ดึงค่า query จาก body
    let prod_id = req.body.productDetail.prod_id;
    let product = req.body.productDetail;

    //update database
    connection.query("UPDATE product_info SET ? WHERE prod_id = ?", [product, prod_id], function (error, results) {
        if (error) throw error;
        return res.send({ error: false, data: results.affectedRows, message: "Product has been updated successfully" });
    });
});

//delete product
/* Testing 1 delete product
method: delete
URL: https://localhost:8008/product-del
body: raw json
{
    "prod_id": "9"
}
*/
/* Testing 2 delete product
method: delete
URL: https://localhost:8008/product-del
body: raw json
{
    "prod_id": "1"
}
*/
router.delete('/product-del', function (req, res) {
    //ดึงค่า query จาก body
    let prod_id = req.body.prod_id;

    //ตรวจสอบว่ามีอยู่จริงมั้ย
    if (!prod_id) {
        return res.status(400).send({ error: true, message: 'Please provide product_id' });
    }

    //delete from database
    connection.query("DELETE FROM product_info where prod_id = ?", [prod_id], function (error, results) {
        if (error) throw error;
        return res.send({ error: false, data: results.affectedRows, message: 'Product has been deleted successfully' });
    });
});


app.listen(process.env.PORT, function() {
    console.log('Server listening at port:'+ process.env.PORT);
});